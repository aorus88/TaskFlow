import React, { useEffect, useContext, useState, useRef, useCallback } from "react";
import { TimerContext } from "../context/TimerContext";
import "./GlobalPomodoroTimer.css";


// Sons de notification
const NOTIFICATION_SOUNDS = {
  sessionComplete: '/sounds/session-complete.mp3',
};

const playSound = (soundType) => {
  try {
    const audio = new Audio(NOTIFICATION_SOUNDS[soundType]);
    audio.play().catch(error => {
      console.warn("Erreur lors de la lecture du son:", error);
    });
  } catch (error) {
    console.warn("Le navigateur ne supporte pas la lecture audio:", error);
  }
};

///////////////////////////////////////////////////////////////////////////////////////////

const GlobalPomodoroTimer = ({ tasks = [], isPreview = false, fetchTasks }) => {
  const {
    timeLeft,
    setTimeLeft,
    isRunning,
    setIsRunning,
    customDuration,
    setCustomDuration,
    selectedTaskId, // Utilisation depuis le contexte
    setSelectedTaskId, // Utilisation depuis le contexte
    sessionTime,
    setSessionTime,
  } = useContext(TimerContext);

  // États locaux
  const [isPaused, setIsPaused] = useState(false);
  const [currentTaskIndex, setCurrentTaskIndex] = useState(null);
  const [sessionCount, setSessionCount] = useState(0);
  const [sessionEnded, setSessionEnded] = useState(false);
  const [isMinimized, setIsMinimized] = useState(() => {
    const saved = localStorage.getItem('pomodoroMinimized');
    return saved ? JSON.parse(saved) : true;
  });
  const [isManualStop, setIsManualStop] = useState(false);
  const [isFloating, setIsFloating] = useState(() => {
    const saved = localStorage.getItem('pomodoroPosition');
    return saved ? JSON.parse(saved) : true;
  });

  // Mettre à jour le gestionnaire pour sauvegarder l'état
  const handleMinimize = () => {
    setIsMinimized(prev => {
      const newValue = !prev;
      localStorage.setItem('pomodoroMinimized', JSON.stringify(newValue));
      return newValue;
    });
  };

  const isSubmitting = useRef(false);
  const timerRef = useRef(null);

  // Sauvegarder la position du pomodoro
  const togglePosition = () => {
    setIsFloating(prev => {
      const newValue = !prev;
      localStorage.setItem('pomodoroPosition', JSON.stringify(newValue));
      return newValue;
    });
  };

  // Restaurer la dernière tâche ou sous-tâche sélectionnée
  useEffect(() => {
    const lastSelectedTaskId = localStorage.getItem('lastSelectedTaskId');
    if (lastSelectedTaskId) {
      const [type, id] = lastSelectedTaskId.split('-');
      const taskExists = type === 'task' 
        ? tasks.some(task => task._id === id)
        : tasks.some(task => task.subtasks?.some(subtask => subtask._id === id));
      
      if (taskExists) {
        setSelectedTaskId(lastSelectedTaskId);
        console.log("Dernière tâche/sous-tâche restaurée:", lastSelectedTaskId);
      }
    }
  }, [tasks]);

  // Mettre à jour le compte des sessions
  useEffect(() => {
    if (selectedTaskId && tasks.length > 0) {
      const [type, id] = selectedTaskId.split('-');
      if (type === 'task') {
        const selectedTask = tasks.find(task => task._id === id);
        if (selectedTask) {
          const taskSessions = selectedTask.sessions.filter(s => s.type === 'task');
          setSessionCount(taskSessions.length);
        }
      } else {
        const parentTask = tasks.find(task => 
          task.subtasks?.some(subtask => subtask._id === id)
        );
        if (parentTask) {
          const subtaskSessions = parentTask.sessions.filter(s => 
            s.type === 'subtask' && s.targetId === id
          );
          setSessionCount(subtaskSessions.length);
        }
      }
    }
  }, [selectedTaskId, tasks]);

  // Gérer le timer avec durée précise
  useEffect(() => {
    if (isRunning && !isPaused) {
      let startTime = Date.now() - (sessionTime * 1000);
      
      timerRef.current = setInterval(() => {
        const elapsedTime = Math.floor((Date.now() - startTime) / 1000);
        
        setTimeLeft((prevTime) => {
          if (prevTime > 0) {
            setSessionTime(elapsedTime);
            return customDuration * 60 - elapsedTime;
          } else {
            if (!sessionEnded && !isSubmitting.current) {
              handleSessionEnd(elapsedTime);
              setSessionEnded(true);
              startNewSession(); // Démarrer nouvelle session
            }
            return 0;
          }
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRunning, isPaused, customDuration, sessionEnded, sessionTime, setSessionTime]);

  const handleSessionEnd = async (totalSeconds = 0) => {
    if (!selectedTaskId || isSubmitting.current) {
      return;
    }

    try {
      isSubmitting.current = true;
      setIsRunning(false);
      playSound('sessionComplete'); // Ajouter le son

      const [type, id] = selectedTaskId.split('-');
     // Arrondir au nombre de minutes sans ajouter de minute supplémentaire
     const sessionTimeInMinutes = Math.floor(totalSeconds / 60);

      const parentTaskId = type === 'subtask' 
        ? tasks.find(task => task.subtasks?.some(st => st._id === id))?._id
        : id;

      if (!parentTaskId) {
        throw new Error("Tâche parente non trouvée");
      }

      const session = {
        duration: sessionTimeInMinutes,
        date: new Date(),
        type: type,
        targetId: id
      };

      const response = await fetch(
        `http://192.168.50.241:4000/tasks/${parentTaskId}/sessions`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(session),
        }
      );

      if (!response.ok) {
        throw new Error("Erreur lors de l'ajout de la session");
      }

      setTimeLeft(customDuration * 60);
      setSessionTime(0);
      setSessionEnded(false);

      if (fetchTasks) {
        await fetchTasks();
      }
    } catch (error) {
      console.error("Erreur:", error);
    } finally {
      isSubmitting.current = false;
    }
  };

  const startNewSession = useCallback(() => {
    if (!isManualStop) {
      setTimeout(() => {
        setTimeLeft(customDuration * 60);
        setSessionTime(0);
        setSessionEnded(false);
        setIsRunning(true);
        playSound('sessionComplete'); // Ajouter le son
      }, 1000);
    }
  }, [customDuration, isManualStop, setTimeLeft, setSessionTime, setIsRunning]);

  const startTimer = useCallback(() => {
    if (!selectedTaskId) {
      alert("Veuillez sélectionner une tâche");
      return;
    }
    setIsRunning(true);
    setIsPaused(false);
    setSessionEnded(false);
  }, [selectedTaskId, setIsRunning]);

  const pauseResumeTimer = useCallback(() => {
    setIsPaused(prev => !prev);
  }, []);

  const resetTimer = useCallback(() => {
    setIsRunning(false);
    setIsPaused(false);
    setTimeLeft(customDuration * 60);
    setSessionTime(0);
    setSessionEnded(false);
    setIsManualStop(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  }, [customDuration, setTimeLeft, setSessionTime]);

  const completeAndAssignTime = useCallback(() => {
    if (!selectedTaskId) {
      alert("Veuillez sélectionner une tâche");
      return;
    }
    setIsManualStop(true);
    handleSessionEnd(sessionTime);
  }, [selectedTaskId, sessionTime]);

  const handleDurationChange = useCallback((value) => {
    const minutes = Number(value);
    if (minutes > 0) {
      setCustomDuration(minutes);
      setTimeLeft(minutes * 60);
    }
  }, [setCustomDuration, setTimeLeft]);

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  if (!tasks?.length) {
    return <div>Aucune tâche disponible</div>;
  }

  const progress = ((customDuration * 60 - timeLeft) / (customDuration * 60)) * 100;
  const segments = 60;
  const segmentProgress = 100 / segments;
  const activeSegments = Math.floor(progress / segmentProgress);

  return (
    <div className={`pomodoro-timer ${!isPreview ? (isFloating ? 'floating' : 'docked') : ''} ${isMinimized ? 'minimized' : ''}`}>
      <div className="timer-header">
        <h1>{formatTime(timeLeft)} ⏱️</h1>
        <h3></h3>
        <div className="timer-controls">
          <button 
            className="dock-button"
            onClick={togglePosition}
          >
            {isFloating ? '📌' : '🔓'}
          </button>
          <button 
            className="minimize-button"
            onClick={() => setIsMinimized(!isMinimized)}
          >
            {isMinimized ? '🔼' : '🔽'}
          </button>
        </div>
      </div>

      <div className={`timer-content ${isMinimized ? 'hidden' : ''}`}>
        <div className="timer-container">
          <div className="progress-bar-container">
            {Array.from({ length: segments }).map((_, index) => (
              <div
                key={index}
                className={`progress-bar-segment ${index < activeSegments ? "active" : "inactive"}`}
                style={{ width: `${segmentProgress}%` }}
              />
            ))}
          </div>
          <span className="timer-display">{formatTime(timeLeft)}</span>
        </div>

        <select
          value={selectedTaskId || ""}
          onChange={(e) => {
            setSelectedTaskId(e.target.value);
            localStorage.setItem('lastSelectedTaskId', e.target.value);
          }}
          className="task-selector"
        >
          <option value="" disabled>Sélectionnez une tâche</option>
          {tasks.map((task) => (
            <React.Fragment key={task._id}>
              <option value={`task-${task._id}`}>
                {task.name}
              </option>
              {/* Filtrer les sous-tâches non archivées */}
              {task.subtasks
            ?.filter(subtask => subtask.archived !== "closed")
            .map((subtask) => (
              <option key={subtask._id} value={`subtask-${subtask._id}`}>
                ├─ {subtask.name}
              </option>
            ))}
        </React.Fragment>
          ))}
        </select>

        <input
          type="number"
          value={customDuration}
          onChange={(e) => handleDurationChange(e.target.value)}
          min="1"
          placeholder="Durée (min)"
          className="duration-input"
        />

        <div className="timer-buttons">
          <button onClick={startTimer} className="start-button" disabled={!selectedTaskId || isRunning}>
            Démarrer ⏱️
          </button>
          <button onClick={pauseResumeTimer} className="pause-button" disabled={!isRunning}>
            {isPaused ? "Reprendre ⏯️" : "Pause ⏸️"}
          </button>
          <button onClick={completeAndAssignTime} className="stop-button" disabled={!selectedTaskId}>
            Terminé ✅
          </button>
          <button onClick={resetTimer} className="reset-button">
            Réinitialiser 🛑
          </button>
        </div>

        <div className="session-info">
          <p>Sessions complétées : {sessionCount}</p>
        </div>
      </div>
    </div>
  );
}

export default GlobalPomodoroTimer;