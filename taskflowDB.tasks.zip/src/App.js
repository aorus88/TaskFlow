import React, { useReducer, useEffect, useState, useCallback } from "react";
import { Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Archives from "./pages/Archives";
import FusionTool from "./pages/FusionTool";
import Sessions from "./pages/Sessions";
import FloatingMenu from "./components/FloatingMenu";
import GlobalPomodoroTimer from "./components/GlobalPomodoroTimer";
import "./index.css";
import "./timer.css";
import taskReducer from "./reducers/taskReducer";
import { TimerProvider } from "./context/TimerContext";
import FeedbackMessage from './components/FeedbackMessage'; // Importer le composant FeedbackMessage

const initialState = {
  tasks: [],
  consumptionEntries: [],
  selectedTaskId: null
};

const App = () => {
  const [state, dispatch] = useReducer(taskReducer, initialState);
  const [feedback, setFeedback] = useState({ message: '', type: '' });
  const [filter, setFilter] = useState({
    priority: "",
    date: "",
    status: "",
    sortOrder: "newest",
  });
  const [isDarkMode, setIsDarkMode] = useState(false);
  const taskCategories = [
    "Travail 💼",
    "Personnel 🐈",
    "Santé - Fusion-Tool 🧬",
    "Finances 💵",
    "Jeux vidéos 🎮",
    "Maison 🏠",
    "Achats 🛒",
    "TaskFlow ⛩️",
    "Autre 📝",
];

const showFeedback = (message, type) => {
  setFeedback({ message, type });
  setTimeout(() => {
    setFeedback({ message: '', type: '' });
  }, 3000); // Le message disparaîtra après 3 secondes
};

  const fetchTasks = useCallback(async (archived = false) => {
    try {
      const response = await fetch(`http://192.168.50.241:4000/tasks?archived=${archived}`);
      if (!response.ok) {
        throw new Error(`HTTP error: ${response.status}`);
      }
      const data = await response.json();
      if (!Array.isArray(data)) {
        console.error("Les données reçues ne sont pas un tableau :", data);
        
        return;
      }
      dispatch({ type: "SET_TASKS", payload: data });
    } catch (error) {
      console.error("Erreur lors du chargement des tâches :", error);
    }
  }, []);

  useEffect(() => {
    fetchTasks();
    fetchTasks(true); // Fetch archived tasks as well
  }, [fetchTasks]);

  const addTask = async (task) => {
    try {
      const response = await fetch('http://192.168.50.241:4000/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(task),
      });
      if (!response.ok) {
        throw new Error('Erreur lors de l\'ajout de la tâche.');
      }
      await fetchTasks();
    } catch (error) {
      console.error('Erreur :', error);
    }
  };

  const updateTask = async (taskId, updatedFields) => {
    try {
      const response = await fetch(`http://192.168.50.241:4000/tasks/${taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedFields),
      });
      if (!response.ok) {
        throw new Error('Erreur lors de la modification de la tâche.');
      }
      await fetchTasks();
    } catch (error) {
      console.error('Erreur :', error);
      showFeedback('Erreur lors de la modification de la tâche.', 'error');
    }
  };

  const deleteTask = async (taskId) => {
    try {
      const response = await fetch(`http://192.168.50.241:4000/tasks/${taskId}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error('Erreur lors de la suppression de la tâche.');
      }
      await fetchTasks();
    } catch (error) {
      console.error('Erreur :', error);
      showFeedback('Erreur lors de la suppression de la tâche.', 'error');
    }
  };

  const archiveTask = async (taskId) => {
    try {
      const response = await fetch(`http://192.168.50.241:4000/tasks/${taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archivedAt: new Date().toISOString(), archived: 'closed' }),
      });
      if (!response.ok) {
        throw new Error('Erreur lors de l\'archivage de la tâche.');
      }
      await fetchTasks();
    } catch (error) {
      console.error('Erreur :', error);
      showFeedback('Erreur lors de l\'archivage de la tâche.', 'error');
    }
  };

  const addSubtask = async (taskId, subtask) => {
    try {
      const response = await fetch(`http://192.168.50.241:4000/tasks/${taskId}/subtasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(subtask),
      });
      if (!response.ok) {
        throw new Error('Erreur lors de l\'ajout de la sous-tâche.');
      }
      await fetchTasks();
    } catch (error) {
      console.error('Erreur :', error);

    }
  };

  const toggleSubtaskStatus = async (taskId, subtaskId, status) => {
    try {
      const response = await fetch(`http://192.168.50.241:4000/tasks/${taskId}/subtasks/${subtaskId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ archived: status }),
      });
      if (!response.ok) {
        throw new Error('Erreur lors de la mise à jour de la sous-tâche.');
      }
      await fetchTasks();
    } catch (error) {
      console.error('Erreur :', error);
    }
  };
  
  const deleteSubtask = async (taskId, subtaskId) => {
    try {
      console.log(`Suppression de la sous-tâche ${subtaskId} de la tâche ${taskId}`);
      const response = await fetch(`http://192.168.50.241:4000/tasks/${taskId}/subtasks/${subtaskId}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Erreur lors de la suppression de la sous-tâche :', errorText);
        throw new Error('Erreur lors de la suppression de la sous-tâche.');
      }
      await fetchTasks();
    } catch (error) {
      console.error('Erreur :', error);
      showFeedback('Erreur lors de la suppression de la sous-tâche.', 'error');
    }
  };

  const fetchConsumptionEntries = useCallback(async () => {
    try {
      const response = await fetch('http://192.168.50.241:4000/consumption-entries');
      if (!response.ok) {
        throw new Error(`HTTP error: ${response.status}`);
      }
      const data = await response.json();
      if (!Array.isArray(data)) {
        console.error("Les données reçues ne sont pas un tableau :", data);
        return;
      }
      dispatch({ type: "SET_CONSUMPTION_ENTRIES", payload: data });
    } catch (error) {
      console.error("Erreur lors du chargement des entrées de consommation :", error);
      dispatch({ type: "SET_CONSUMPTION_ENTRIES", payload: [] });
    }
  }, []);

  const addConsumptionEntry = async (entry) => {
    try {
      const response = await fetch('http://192.168.50.241:4000/consumption-entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(entry),
      });
      if (!response.ok) {
        throw new Error('Erreur lors de l\'ajout de l\'entrée de consommation.');
      }
      await fetchConsumptionEntries();
    } catch (error) {
      console.error('Erreur :', error);
    }
  };

  const deleteConsumptionEntry = async (entry) => {
    try {
      const response = await fetch(`http://192.168.50.241:4000/consumption-entries/`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(entry),
      });
      if (!response.ok) {
        throw new Error('Erreur lors de la suppression de l\'entrée de consommation.');
      }
      await fetchConsumptionEntries();
    } catch (error) {
      console.error('Erreur :', error);
    }
  };

  useEffect(() => {
    fetchTasks();
    fetchConsumptionEntries();
  }, [fetchTasks, fetchConsumptionEntries]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.body.classList.toggle('dark', !isDarkMode);
  };

  const updateTaskTime = async (taskId, session) => {
    try {
      const response = await fetch(`http://192.168.50.241:4000/tasks/${taskId}/sessions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(session),
      });
      if (!response.ok) {
        throw new Error("Erreur lors de l'ajout de la session.");
      }
      await fetchTasks();
    } catch (error) {
      console.error("Erreur lors de la mise à jour du temps de la tâche :", error);
    }
  };

  return (
    <TimerProvider>
      <div className={`App ${isDarkMode ? 'dark' : ''}`}>
        <FeedbackMessage message={feedback.message} type={feedback.type} />
        <FloatingMenu addTask={addTask} />
        <Routes>
          <Route
            path="/"
            element={
              <Home
                tasks={state.tasks}
                onAddTask={addTask}
                onEditTask={updateTask}
                onDeleteTask={deleteTask}
                onArchiveTask={archiveTask}
                onAddSubtask={addSubtask}
                onDeleteSubtask={deleteSubtask}
                onToggleSubtaskStatus={toggleSubtaskStatus}
                onSaveTask={updateTask}
                filter={filter}
                setFilter={setFilter}
                fetchTasks={fetchTasks}
                updateTaskTime={updateTaskTime}
                setSelectedTaskId={(taskId) => dispatch({ type: "SET_SELECTED_TASK_ID", payload: taskId })}
                isDarkMode={isDarkMode}
                toggleDarkMode={toggleDarkMode}
                taskCategories={taskCategories} // Passer les catégories en prop
                showFeedback={showFeedback} // Passer la fonction showFeedback en prop
              />
            }
          />
          <Route
            path="/archives"
            element={
              <Archives
              archivedTasks={state.tasks.filter((task) => task.archived?.trim() === "closed")}
              archivedSubtasksWithOpenParent={state.tasks.flatMap(task =>
                task.subtasks.filter(subtask => subtask.archived === "closed" && task.archived !== "closed").map(subtask => ({
                  ...subtask,
                  parentTaskName: task.name,
                  parentTaskId: task._id,
                }))
              )}
              handleDeleteTask={deleteTask}
              onFetchArchivedTasks={() => fetchTasks(true)}
              showFeedback={showFeedback}
            />
            }
      

          />
          <Route path="/fusion-tool" 
          element={
          <FusionTool 
          entries={state.consumptionEntries} 
          onAddEntry={addConsumptionEntry} 
          onDeleteEntry={deleteConsumptionEntry}
          showFeedback={showFeedback}
          />} />
          <Route path="/sessions" 
          element={<Sessions />}
          showFeedback={showFeedback}
           />


          
        </Routes>
      </div>
    </TimerProvider>
  );
};

export default App;